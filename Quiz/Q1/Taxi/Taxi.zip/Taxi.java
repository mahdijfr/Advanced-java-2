import java.math.BigDecimal;

public interface Taxi {
    BigDecimal getPrice(Point src, Point dest);
}
