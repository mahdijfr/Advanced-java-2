package ir.digipay.digiwallet.model;

public enum TransactionType {
    DEPOSIT, WITHDRAWAL
}
