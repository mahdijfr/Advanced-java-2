package ir.digipay.digiwallet.model;

public enum TransactionStatus {
    CANCELED, PENDING, ACCEPTED
}
