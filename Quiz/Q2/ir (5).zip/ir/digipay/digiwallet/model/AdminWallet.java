package ir.digipay.digiwallet.model;

public class AdminWallet extends Wallet {
    public AdminWallet(String id) {
        super(id);
    }
}
