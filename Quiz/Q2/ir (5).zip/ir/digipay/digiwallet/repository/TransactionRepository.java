package ir.digipay.digiwallet.repository;

import ir.digipay.digiwallet.model.Transaction;

public interface TransactionRepository extends CrudRepository<Transaction, Long> {
}
